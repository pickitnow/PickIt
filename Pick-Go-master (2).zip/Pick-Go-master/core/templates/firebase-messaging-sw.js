importScripts("https://www.gstatic.com/firebasejs/8.2.1/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/8.2.1/firebase-messaging.js");

firebase.initializeApp({
    apiKey: "AIzaSyDtJpZDAwHU0kRTSdkwQZwTFWQP6p8oRFM",
    authDomain: "pickngo-340506.firebaseapp.com",
    projectId: "pickngo-340506",
    storageBucket: "pickngo-340506.appspot.com",
    messagingSenderId: "583942178044",
    appId: "1:583942178044:web:67a75100a46be4e56fc379",
    measurementId: "G-FVRE8QHT2T"

});
const messaging = firebase.messaging();